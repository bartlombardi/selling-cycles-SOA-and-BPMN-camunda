package it.unibo.soseng.sellingcycles;

import org.camunda.bpm.application.ProcessApplication;
import org.camunda.bpm.application.impl.ServletProcessApplication;

@ProcessApplication("Selling Cycles App")
public class SellingCyclesApplication extends ServletProcessApplication {
	// Empty Implementation
}
